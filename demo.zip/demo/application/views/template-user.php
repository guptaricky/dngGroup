<!DOCTYPE html>
<div><?php echo $header; ?></div>
<div><?php echo $sidebar; ?></div>
<div><?php echo $content; ?></div>
<div><?php echo $footer; ?></div>