<!DOCTYPE html>
<html>
    <head>
    
    
    </head>
    <body>
        <div class="body_container">
        	<?php echo $content; ?>
        </div>
    </body>

</html>