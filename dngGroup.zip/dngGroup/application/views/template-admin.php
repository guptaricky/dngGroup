<!DOCTYPE html>
<html>
    <head>
    
    </head>
    <body>
    	<div class="header">
        	<?php //echo $header; ?>
        </div>
        <div class="body_container">
        	<?php echo $content; ?>
        </div>
        <div class="footer">
        	<?php echo $footer; ?>
        </div>
    </body>
</html>